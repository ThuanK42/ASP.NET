﻿namespace QuanLySinhVien
{
    internal class QuanLySinhVienDataSet
    {
    }
}