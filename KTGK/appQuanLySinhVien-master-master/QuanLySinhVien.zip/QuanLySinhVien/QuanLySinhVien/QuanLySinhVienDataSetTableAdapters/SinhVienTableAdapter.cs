﻿namespace QuanLySinhVienDataSetTableAdapters
{
    internal class SinhVienTableAdapter
    {
    }
}