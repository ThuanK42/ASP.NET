﻿using System.Collections;

namespace QuanLySinhVien.DAO
{
    internal class ArrayList<T> : ArrayList
    {
    }
}