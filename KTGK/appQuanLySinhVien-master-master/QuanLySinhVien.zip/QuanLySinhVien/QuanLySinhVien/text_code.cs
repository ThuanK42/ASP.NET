﻿namespace QuanLySinhVien
{
    internal class text_code
    {
    }
}