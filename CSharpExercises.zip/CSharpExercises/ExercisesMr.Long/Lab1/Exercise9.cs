﻿using System;

namespace Lab1
{
    public class Exercise9
    {
        private int[,] _data;
        public Exercise9()
        {
            this._data = new int[15,15];
        }

        public void print()
        {
            
        }

        static void Main(string[] args)
        {
            
        }
    }
}