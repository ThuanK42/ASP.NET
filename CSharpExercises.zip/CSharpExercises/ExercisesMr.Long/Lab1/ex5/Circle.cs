﻿using System;

namespace Lab1.ex5
{
    public class Circle : IShape
    {
        static double PI = Math.PI;

        private double radius;

        //overide ghi lai phan xu ly chu ko dua vao input

        public Circle(double radius)
        {
            this.radius = radius;
        }

        #region perimeter and area
        public double perimeter()
        {
            if (radius > 0)
                return 2 * radius * PI;
            return 0;
            
        }

        public double area()
        {
            if (radius > 0)
                return radius * radius * PI;
            return 0;
        }
        
        #endregion
        
    }
}