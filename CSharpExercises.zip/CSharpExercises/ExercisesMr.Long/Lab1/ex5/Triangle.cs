﻿using System;

namespace Lab1.ex5
{
    public class Triangle : IShape
    {

        private double a, b, c;

        public Triangle(double a, double b, double c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        
        #region perimeter and area
        
        public double perimeter()
        {
            if (a > 0 && b > 0 && c > 0)
                return a+b+c;
            return 0;
        }

        public double area()
        {
            if (a < 0 || b < 0 || c <0 ||  
                a + b <= c || a + c <=b ||  
                b + c <=a)
            {
                return 0;
            } 
            double s = (a + b + c) / 2; 
            return Math.Sqrt(s * (s - a) *  
                             (s - b) * (s - c)); 
        }
        
        #endregion
    }
}