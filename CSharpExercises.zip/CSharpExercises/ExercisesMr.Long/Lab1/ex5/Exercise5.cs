﻿using System;
namespace Lab1.ex5
{
    public class Exercise5
    {
        
        static void Main(string[] args)
        {

            Rectangle rectangle;
            Circle circle;
            Triangle triangle;
            
            while (true)
            {
                Console.WriteLine("The program calculates the circumference and area");
                Console.WriteLine("Calculate the circumference of a circle. Press 1");
                Console.WriteLine("Calculate the area of a circle. Press 2");
                Console.WriteLine("Calculate the perimeter of the triangle. Press 3");
                Console.WriteLine("Calculate the area of the triangle. Press 4");
                Console.WriteLine("Calculate the perimeter of a rectangle. Press 5");
                Console.WriteLine("Find the area of a rectangle. Press 6");
                Console.WriteLine("Want to exit the program? haha? Impossible");
                Console.WriteLine("Currently,this program will automatically return 0 if you enter an absurd number");
                int number = int.Parse(Console.ReadLine());
                switch (number)
                {
                    case 1:
                        Console.WriteLine("Enter radius");
                        double radius = double.Parse(Console.ReadLine());
                        Console.WriteLine("Is this the result?");
                        circle = new Circle(radius);
                        Console.WriteLine(circle.perimeter());
                        Console.WriteLine("\n \n \n");
                        break;
                    
                    case 2:
                        Console.WriteLine("Enter radius");
                        double radius2 = double.Parse(Console.ReadLine());
                        circle = new Circle(radius2);
                        Console.WriteLine("Is this the result?");
                        Console.WriteLine(circle.area());
                        Console.WriteLine("\n \n \n");
                        break;
                    
                    case 3:
                        Console.WriteLine("Enter the three sides of the triangle:");
                        Console.WriteLine("Next to a?");
                        double a = double.Parse(Console.ReadLine());
                        Console.WriteLine("Next to b?");
                        double b = double.Parse(Console.ReadLine());
                        Console.WriteLine("Next to c?");
                        double c = double.Parse(Console.ReadLine());
                        triangle = new Triangle(a,b,c);
                        Console.WriteLine("Is this the result?");
                        Console.WriteLine(triangle.perimeter());
                        Console.WriteLine("\n \n \n");
                        break;
                    
                    case 4:
                        Console.WriteLine("Enter the three sides of the triangle:");
                        Console.WriteLine("Next to a?");
                        double a2 = double.Parse(Console.ReadLine());
                        Console.WriteLine("Next to b?");
                        double b2 = double.Parse(Console.ReadLine());
                        Console.WriteLine("Next to c?");
                        double c2 = double.Parse(Console.ReadLine());
                        triangle = new Triangle(a2,b2,c2);
                        Console.WriteLine("Is this the result?");
                        Console.WriteLine(triangle.area());
                        Console.WriteLine("\n \n \n");
                        break;
                    
                    case 5:
                        Console.WriteLine("Enter the 2 sides of the rectangle");
                        Console.WriteLine("Next to a?");
                        double a3 = double.Parse(Console.ReadLine());
                        Console.WriteLine("Next to b?");
                        double b3 = double.Parse(Console.ReadLine());
                        Console.WriteLine("Is this the result?");
                        rectangle = new Rectangle(a3,b3);
                        Console.WriteLine(rectangle.perimeter());
                        Console.WriteLine("\n \n \n");
                        break;
                    
                    case 6:
                        Console.WriteLine("Enter the 2 sides of the rectangle");
                        Console.WriteLine("Next to a?");
                        double a4 = double.Parse(Console.ReadLine());
                        Console.WriteLine("Next to b?");
                        double b4 = double.Parse(Console.ReadLine());
                        Console.WriteLine("Is this the result?");
                        rectangle = new Rectangle(a4,b4);
                        Console.WriteLine(rectangle.area());
                        Console.WriteLine("\n \n \n");
                        break;
                    
                    default:
                        Console.WriteLine("I told you not to type it wrong. The show stops here. Have a nice day");
                        System.Environment.Exit(0);
                        break;
                }
            }
        }
    }
}