﻿namespace Lab1.ex5
{
    public class Rectangle : IShape
    {

        private double a, b;

        public Rectangle(double a, double b)
        {
            this.a = a;
            this.b = b;
        }
        
        #region perimeter and area
        public double perimeter()
        {
            if (a > 0 && b > 0)
                return (a+b) * 2;
            return 0;
        }

        public double area()
        {
            if (a > 0 && b > 0)
                return a*b;
            return 0;
        }
        
        #endregion
    }
}