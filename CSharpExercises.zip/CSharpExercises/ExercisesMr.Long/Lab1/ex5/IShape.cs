﻿namespace Lab1.ex5
{
    public interface IShape
    {
        public double perimeter();

        public double area();
    }
}