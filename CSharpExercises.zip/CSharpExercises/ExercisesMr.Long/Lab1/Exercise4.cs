﻿using System;

namespace Lab1
{
    public class Exercise4
    {
        #region factorial(int n)

        static int factorial(int n) 
        { 
            if (n == 0) 
                return 1; 
  
            return n * factorial(n - 1); 
        }

        #endregion
        
        static void Main(string[] args)
        {
            while (true)
            {
                Console.WriteLine("Moi ban nhap so: ");
                int x = int.Parse(Console.ReadLine());
                Console.WriteLine(factorial(x));

            }
        }
    }
}