﻿using System;

namespace Lab1
{
    public class Exercise7
    {
        #region charging_taxi

        static void charging_taxi(double km)
        {
            double total = 0;
            if (km>0 && km <= 1)
            {
                total = 10000;
                Console.WriteLine("The first 1km taxi ride is "+total);
            }else if (km >1 && km <= 21)
            {
                total = 10000 + 9500*(km-1);
                Console.WriteLine("The amount of 21km taxi ride is "+total);
            }
            else if (km > 21)
            {
                total = 10000 + 9500*20 + 9000 * (km-1-20);
                Console.WriteLine("The amount of taxi ride is over 21km "+total);
            }
            else
            {
                Console.WriteLine("The amount of 0 km taxi ride is 0");
            }
        }
        
        #endregion
    }
}