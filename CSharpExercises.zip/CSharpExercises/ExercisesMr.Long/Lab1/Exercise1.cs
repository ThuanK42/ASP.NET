﻿using System;

namespace Lab1
{

    public class Exercise1
    {
        #region ReadNumber(int number)
        public static string ReadNumber(int number)
        {
            try
            {
                if (number >= 100 && number % 100 == 0 && number <= 999)
                {
                    return String.Format("So {0} co: {1} tram", number, number / 100);
                }
                else if (number >= 100 && number % 100 != 0 && number <= 999)
                {
                    int hundreds = number / 100;
                    int dozens = (number - (hundreds * 100)) / 10;
                    int unit = number - (hundreds * 100) - (dozens * 10);
                    return String.Format("So {0} co: {1} tram {2} chuc {3} don vi", number, hundreds, dozens, unit);
                }
                else
                {
                    return "Chi duoc nhap 1 so nguyen duong tu 100-999";
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }
        
        #endregion

        static void Main(string[] args)
        {

            while (true)
            {
                Console.WriteLine("Moi ban nhap so: ");
                int number = int.Parse(Console.ReadLine());
                Console.WriteLine(ReadNumber(number));
            }

        }
    }
}