﻿using System;

namespace Lab1
{
    public class Exercise6
    {
        #region Array

        static int sumArray(int[] arr)
        {
            int sum = 0 ;
            for (int i = 0; i < arr.Length; i++)
            {
                sum += arr[i];
            }

            return sum;
        }
        
        static void parity_element_count(int[] arr)
        {
            int countEven = 0 ;
            int countOdd = 0 ;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] % 2 == 0)
                {
                    countEven++;
                }
                else
                {
                    countOdd++;
                }
            }

           Console.WriteLine("The even number of elements is"+countEven);
           Console.WriteLine("The odd number of elements is"+countOdd);
        }

        static void findMaxElement(int[] arr)
        {
            int temp = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i]>temp)
                {
                    temp = arr[i];
                }
            }
            Console.WriteLine("Max: "+temp);
        }
        
        static void findMinElement(int[] arr)
        {
            int temp = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i]<temp)
                {
                    temp = arr[i];
                }
            }
            Console.WriteLine("Min: "+temp);
        }
        
        static void is_increment_array(int[] arr)
        {
            int temp;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i+1; j < arr.Length-1; j++)
                {
                    if (arr[i] > arr[j])
                    {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            
            Console.WriteLine("increment_array:");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }

        }
        
        static void is_descending_array(int[] arr)
        {
            int temp;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i+1; j < arr.Length-1; j++)
                {
                    if (arr[i] < arr[j])
                    {
                        temp = arr[i];
                        arr[i] = arr[j];
                        arr[j] = temp;
                    }
                }
            }
            
            Console.WriteLine("descending_array:");
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }

        static void findElement(int[] arr, int number)
        {
            int temp = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i]== number)
                {
                    Console.WriteLine("The element to find is in position: "+i);
                }
            }
            
        }
        
        static void countElementAppear(int[] arr, int number)
        {
            int count = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i]== number)
                {
                    count++;
                }
            }
            Console.WriteLine("Element: "+number+" appear "+count+" times");
        }
        
        static bool check_increment_array(int[] arr)
        {
            bool rs =true;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i+1; j < arr.Length-1; j++)
                {
                    if (arr[i] > arr[j])
                        rs = false;
                }
            }
            return rs;
        }
        
        static bool check_desc_array(int[] arr)
        {
            bool rs =true;
            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = i+1; j < arr.Length-1; j++)
                {
                    if (arr[i] < arr[j])
                        rs = false;
                }
            }
            return rs;
        }

        static void breakwhenfind5()
        {
            for (int i = 0; i < 7; i++)
            {
                if (i == 5) 
                    break;
                Console.Write(i+" ");
            }
        }
        
        static void notprint5kwhenfind5()
        {
            for (int i = 0; i < 7; i++)
            {
                if (i == 5) 
                    continue;
                Console.Write(i+" ");
            }
        }
        
        
        

        #endregion
    }
}