﻿using System;

namespace Lab1
{
    public class Exercise2
    {
        #region ArmstrongNumber
        public static bool ArmstrongNumber(int number)
        {
            try
            {
                int sum;
                if (number >= 100 && number <= 999)
                {
                    int hundreds = number / 100;
                    int dozens = (number - hundreds * 100) / 10;
                    int unit = number - (hundreds * 100 + dozens * 10);

                    sum = Convert.ToInt32(Math.Pow(hundreds, 3) + Math.Pow(dozens, 3) + Math.Pow(unit, 3));
                    
                    if (number == sum)
                    {
                        return true;
                    }
                }
                return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                throw;
            }
        }

        #endregion
        
        static void Main(string[] args)
        {

            while (true)
            {
                Console.WriteLine("Moi ban nhap so: ");
                int number = int.Parse(Console.ReadLine());
                if (ArmstrongNumber(number))
                {
                    Console.WriteLine("is amstrong number");
                }
                else
                {
                    Console.WriteLine("not is amstrong number");
                }
                
            }

        }
    }
}