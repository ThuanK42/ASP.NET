﻿using System.Collections.Generic;
using System.Linq;

namespace Lab1
{
    public class ListClass
    {
        List<Classes> listClasseses;

        public ListClass()
        {
            listClasseses = new List<Classes>();
        }

        public void AddClasses(Classes c)
        {
            listClasseses.Add(c);
        }

        public void RenameClasses(string codeClass2,string nameClass2)
        {
            
            foreach (Classes classes in listClasseses)
            {
                if (classes.CodeClass.Equals(codeClass2))
                {
                    classes.NameClass = nameClass2;
                }
            }
        }

        public void DeleteClasses(string codeClass2)
        {
            
            foreach (Classes classes in listClasseses.ToList())
            {
                if (classes.CodeClass.Equals(codeClass2))
                {
                    listClasseses.Remove(classes);
                    classes.ListStudents.DeleteAllStudent();
                }
            }
        }

        public void FindClassById(string codeClass)
        {
            foreach (Classes t in listClasseses)
            {
                if (t.CodeClass == codeClass)
                {
                    t.ShowInfoClass();
                    
                }
            }
        }
        public void AddStudentIntoClass(Student student)
        {
            foreach (Classes classes in listClasseses)
            {
                if (classes.CodeClass.Equals(student.CodeClass))
                {
                    classes.ListStudents.AddStudents(student);
                }
            }
        }
        
        public void ChangeNameStudentInClass(string codeClass,string codeStudent,string nameStudent)
        {
            foreach (Classes classes in listClasseses)
            {
                if (classes.CodeClass==codeClass)
                {
                    if (classes.ListStudents.CheckCodeStudentExist(codeStudent))
                    {
                        classes.ListStudents.ChangeNameStudent(codeStudent,nameStudent);
                    }
                }
            }
        }
        public void DeleteNameStudentInClass(string codeClass,string codeStudent)
        {
            foreach (Classes classes in listClasseses)
            {
                if (classes.CodeClass.Equals(codeClass))
                {
                    if (classes.ListStudents.CheckCodeStudentExist(codeStudent))
                    {
                        classes.ListStudents.DeleteStudent(codeStudent);
                    }
                }
            }
        }
        
    }
}