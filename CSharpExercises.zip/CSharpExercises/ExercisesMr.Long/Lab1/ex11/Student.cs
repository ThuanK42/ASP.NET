﻿using System.Collections.Generic;

namespace Lab1
{
    public class Student
    {
        private string _codeStudent,_nameStudent,_codeClass;
        private List<Student> _listStudents= new List<Student>();

        public Student(string codeStudent, string nameStudent,string codeClass)
        {
            _codeStudent = codeStudent;
            _nameStudent = nameStudent;
            _codeClass = codeClass;
        }

        public string CodeStudent
        {
            get => _codeStudent;
            set => _codeStudent = value;
        }

        public string NameStudent
        {
            get => _nameStudent;
            set => _nameStudent = value;
        }

        public string CodeClass
        {
            get => _codeClass;
            set => _codeClass = value;
        }

        public List<Student> ListStudents
        {
            get => _listStudents;
            set => _listStudents = value;
        }

        public  string ShowInfoStudent()
        {
            return "[CodeStudent: "+_codeStudent+", Name Student: "+_nameStudent+", Class : "+_codeClass+"]";
        }
    }
}