﻿using System.Collections.Generic;

namespace Lab1
{
    public class ListStudents
    {
        List<Student> _listStudents ;

        public ListStudents()
        {
            _listStudents =  new List<Student>();
        }

        public void AddStudents(Student student)
        {
            _listStudents.Add(student);
        }
        
        public void ChangeNameStudent(string codeStudent,string nameStudent)
        {
            foreach (Student st in _listStudents)
            {
                if (st.CodeStudent.Equals(codeStudent))
                {
                    st.NameStudent = nameStudent;
                }
            }
        }
        
        public void DeleteStudent(string codeStudent)
        {
            foreach (Student st in _listStudents)
            {
                if (st.CodeStudent == codeStudent)
                {
                    _listStudents.Remove(st);
                    break;
                }
            }
        }
        
        public void DeleteAllStudent()
        {
            _listStudents.Clear();
        }

        public string ShowListStudent()
        {
            string rs = "";
            foreach (Student t in _listStudents)
            {
                rs += t.ShowInfoStudent()+"\n \t \t \t                 ";
            }

            return rs;
        }

        public bool CheckCodeStudentExist(string codeStudent)
        {
            foreach (Student t in _listStudents)
            {
                if (t.CodeStudent.Equals(codeStudent))
                {
                    return true;
                }
            }

            return false;
        }
        
    }
}