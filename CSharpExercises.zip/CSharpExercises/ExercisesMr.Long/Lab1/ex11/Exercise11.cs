﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Lab1
{
    class TestPrograme
    {
        static void Main(string[] args)
        {

            // Student s = new Student("16130606","Le Van Thuan","DH16DTA");
            // Student s2 = new Student("16130553","Tran Viet Son","DH16DTA");
            // Student s3 = new Student("16130529","Nguyen Van Quang","DH16DTA");
            // Student s4 = new Student("16130379","Nguyen Hieu","DH16DTA");
            // Student s5 = new Student("16130671","Nguyen Hoang Vu","DH16DTA");
            //
            // Student s6 = new Student("16130312","Dang Van Da","DH16DTB");
            // Student s7 = new Student("16130326","Tran Thanh Dien","DH16DTB");
            // Student s8 = new Student("16130583","Le Thi Be Thao","DH16DTB");
            //
            // ListStudents ls = new ListStudents();
            // ls.addStudents(s);
            // ls.addStudents(s2);
            // ls.addStudents(s3);
            // ls.addStudents(s4);
            // ls.addStudents(s5);
            //
            // ListStudents ls2 = new ListStudents();
            // ls2.addStudents(s6);
            // ls2.addStudents(s7);
            // ls2.addStudents(s8);
            //
            // Classes c = new Classes("DH16DTA","CNTT A",ls);
            // Classes c2 = new Classes("DH16DTB","CNTT B",ls2);
            //
            // ListClass lc = new ListClass();
            // lc.addClasses(c);
            // lc.addClasses(c2);
            
            // lc.addClasses(new Classes("DH16DTC","CNTTC",new ListStudents()));
            // lc.renameClasses("DH16DTC","CNTTDH16DTC");
            // lc.deleteClasses("DH16DTB");
            
            // lc.findClassByID("DH16DTB");
            ListClass lc = new ListClass();
            Classes classes;
            Student student;
            ListStudents listStudents;
            Console.WriteLine("\t \t \t ******* ******* Student management ******* ******* \t \t \t \n");
            while (true)
            {
                Console.WriteLine("\t \t \t *******         Add Class. Press 1         *******");
                Console.WriteLine("\t \t \t *******         Change Class. Press 2      *******");
                Console.WriteLine("\t \t \t *******         Delete Class. Press 3      *******");
                Console.WriteLine("\t \t \t *******         Print Class. Press 4       *******");
                Console.WriteLine("\t \t \t *******         Add Student. Press 5       *******");
                Console.WriteLine("\t \t \t *******         Rename Student. Press 6    *******");
                Console.WriteLine("\t \t \t *******         Delete Student. Press 7    *******\n");
                int number = int.Parse(Console.ReadLine());
                switch (number)
                {
                    case 1:
                        Console.Write("\t \t \t =>              Enter CodeClass:");
                        string codeClass = Console.ReadLine();
                        Console.Write("\t \t \t =>              Enter NameClass:");
                        string nameClass = Console.ReadLine();
                        listStudents= new ListStudents();
                        classes = new Classes(codeClass,nameClass,listStudents);
                        lc.AddClasses(classes);
                        Console.WriteLine(" \n ");

                        break;
                    case 2:
                        Console.Write("\t \t \t =>              Enter CodeClass:");
                        string codeClass2 = Console.ReadLine();
                        Console.Write("\t \t \t =>              Enter Rename Class:");
                        string nameClass2 = Console.ReadLine();
                        
                        lc.RenameClasses(codeClass2,nameClass2);
                        Console.Write(" \n ");

                        break;
                    case 3:
                        Console.Write("\t \t \t =>              Enter CodeClass:");
                        string codeClass3 = Console.ReadLine();
                        lc.DeleteClasses(codeClass3);
                        Console.WriteLine(" \n ");

                        break;
                    case 4:
                        Console.Write("\t \t \t =>              Enter CodeClass:");
                        string codeClass4 = Console.ReadLine();
                        lc.FindClassById(codeClass4);
                        Console.WriteLine(" \n ");

                        break;
                    case 5:
                        Console.Write("\t \t \t =>              Enter Code Student:");
                        string codeStudent = Console.ReadLine();
                        Console.Write("\t \t \t =>              Enter Name Student:");
                        string nameStudent = Console.ReadLine();
                        Console.Write("\t \t \t =>              Enter Code Class:");
                        string codeClass5 = Console.ReadLine();
                        student = new Student(codeStudent,nameStudent,codeClass5);
                        lc.AddStudentIntoClass(student);
                        Console.WriteLine(" \n ");

                        break;
                    case 6:
                        Console.Write("\t \t \t =>              Enter Code Class");
                        string codeClass6 = Console.ReadLine();
                        Console.Write("\t \t \t =>              Enter Code Student:");
                        string codeStudent2 = Console.ReadLine();
                        Console.Write("\t \t \t =>              Enter The Name To Change");
                        string nameStudent2 = Console.ReadLine();
                        lc.ChangeNameStudentInClass(codeClass6,codeStudent2,nameStudent2);
                        Console.WriteLine(" \n ");

                        break;
                    case 7:
                        Console.Write("\t \t \t =>              Enter Code Class:");
                        string codeClass7 = Console.ReadLine();
                        Console.Write("\t \t \t =>              Enter Code Student:");
                        string nameStudent7 = Console.ReadLine();
                        lc.DeleteNameStudentInClass(codeClass7,nameStudent7);
                        Console.WriteLine(" \n ");
                        break;
                    default:
                        Console.WriteLine("\t \t \t *******         Cam on ban da dung chuong trinh cua chung toi");
                        break;
                }
            }

        }
    }

}