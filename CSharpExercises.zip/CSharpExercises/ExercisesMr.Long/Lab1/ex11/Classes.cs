﻿using System;

namespace Lab1
{
    public class Classes
    {
        private string _nameClass, _codeClass;
        private ListStudents _listStudents;

        public Classes(string codeClass,string nameClass,ListStudents listsStudents)
        {
            _nameClass = nameClass;
            _codeClass = codeClass;
            _listStudents = listsStudents;
        }

        public string NameClass
        {
            get => _nameClass;
            set => _nameClass = value;
        }

        public ListStudents ListStudents
        {
            get => _listStudents;
            set => _listStudents = value;
        }

        public string CodeClass
        {
            get => _codeClass;
            set => _codeClass = value;
        }

        public void ShowInfoClass()
        {
            Console.WriteLine("\t \t \t =>              Code Class: "+_codeClass+", Name Class: "+_nameClass+", \n \t \t \t                 List Student: "+_listStudents.ShowListStudent());
        }
        
    }
}