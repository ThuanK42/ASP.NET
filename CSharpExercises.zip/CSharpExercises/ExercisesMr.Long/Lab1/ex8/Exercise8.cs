﻿using System;

namespace Lab1
{
    public class Exercise8
    {
        private int a, b, c;
        public Exercise8(int a, int b, int c)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }
        
        static void findRoots(Exercise8 e8) 
        {

            if (e8.a == 0) 
            { 
                Console.Write("Invalid"); 
                return; 
            } 
  
            int d = e8.b*e8.b - 4*e8.c*e8.a; 
            double sqrt_val = Math.Abs(d); 
  
            if (d > 0) 
            { 
                Console.Write("Roots are real and different \n"); 
  
                Console.Write((double)(-e8.b + sqrt_val) /  
                    (2 * e8.a) + "\n"    + (double) 
                    (-e8.b - sqrt_val) / (2 * e8.a)); 
            } 
            
            else 
            { 
                Console.Write("Roots are complex \n"); 
  
                Console.Write( -(double)e8.b / ( 2 * e8.a ) +  
                               " + i" + sqrt_val + "\n"  +  
                               -(double)e8.b / ( 2 * e8.a ) +  
                               " - i" + sqrt_val); 
            } 
        }

        static void Main(string[] args)
        {
            Exercise8 e8 = new Exercise8(2,4,10);
            findRoots(e8);
        }  

    }
}