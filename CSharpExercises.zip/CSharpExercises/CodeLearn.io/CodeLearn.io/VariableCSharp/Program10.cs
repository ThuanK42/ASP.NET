﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program10
    {
        /*static void Main(string[] args)
        {
            int a = 8343;
            int b = 6453;
            Console.WriteLine("a - b = " + (a - b));
        }*/
    }
}
