﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program13
    {
        /*static void Main(string[] args)
        {
            string name = "Codelearn";
            int dob = 2019;
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Date of birth: " + dob);
        }*/
    }
}
