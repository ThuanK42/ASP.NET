﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program17
    {
        /*
         Kiểu ký tự bản chất là một kiểu số nguyên, bạn có thể hiện thị giá trị nguyên của một ký tự bằng câu lệnh (int)ký_tự;
         */

/*        static void Main(string[] args)
        {
            char d = (char)('a' + 3);
            Console.WriteLine(d);
        }*/
    }
}
