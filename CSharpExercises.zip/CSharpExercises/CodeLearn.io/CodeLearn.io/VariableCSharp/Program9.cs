﻿using System;

namespace VariableCSharp
{
    class Program9
    {
        /*static void Main(string[] args)
        {
            //Để khai báo biến kiểu số nguyên trong C# bạn sử dụng từ khóa int (int và viết tắt của integer)
            int a = 254;
            int b = 343;
            Console.WriteLine("a + b = " + (a + b));
        }*/
    }
}
