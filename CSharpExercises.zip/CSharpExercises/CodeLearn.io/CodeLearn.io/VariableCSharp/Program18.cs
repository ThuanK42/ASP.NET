﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program18
    {
        /*
         Miền giá trị của kiểu byte là từ -128 tới  127.
         Miền giá trị của kiểu short là từ -32768 tới 32767.
         Miền giá trị của kiểu int là từ -2147483648 tới 2147483647.
         Miền giá trị của kiểu long là từ -9223372036854775808 tới 9223372036854775807.
         */

/*        static void Main(string[] args)
        {
            int a = 384847522;
            int b = 988347273;
            Console.WriteLine((long)a * b);
        }*/
    }
}
