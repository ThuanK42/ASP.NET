﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program16
    {
        /*
         Kiểu ký tự trong C# là kiểu dữ liệu chỉ lưu trữ được 1 ký tự trong bảng mã UTF-16, 
        ký tự này có thể là một chữ cái (a, b, c, ... x, y, z), một chữ số  (0, 1, 2,..., 9), 
        một phép toán (+, -, *, /) hay một ký tự bất kỳ khác (!, &, ...).
        Biến kiểu ký tự được khai báo bằng từ khóa char (char là viết tắt của character)
         */

        /* static void Main(string[] args)
         {
             char c = 'x';
             Console.WriteLine(c);
         }*/
    }
}
