﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program19
    {
        /*
         * kiểu bool (kiểu luận lý). Kiểu dữ liệu này chỉ nhận 2 giá trị là true và false (tương ứng với đúng và sai)
         */
/*        static void Main(string[] args)
        {
            bool a = true;
            bool b = false;
            Console.WriteLine(a);
            Console.WriteLine(b);
        }*/
    }
}
