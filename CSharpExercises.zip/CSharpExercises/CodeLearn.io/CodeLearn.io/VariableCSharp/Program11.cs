﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program11
    {
        /*static void Main(string[] args)
        {
            int a = 6;
            int b = 2;
            Console.WriteLine("a + b = " + (a + b));
            Console.WriteLine("a - b = " + (a - b));
            Console.WriteLine("a * b = " + (a * b));
            Console.WriteLine("a / b = " + (a / b));
        }*/
    }
}
