﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program14
    {
       /* static void Main(string[] args)
        {
            double a = 3;
            int b = 2;
            Console.WriteLine("a / b = " + a / b);
        }*/
    }
}
