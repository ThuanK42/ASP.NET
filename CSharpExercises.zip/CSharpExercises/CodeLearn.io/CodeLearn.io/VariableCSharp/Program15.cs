﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program15
    {
        /*static void Main(string[] args)
        {
            double length = 1;
            double width = 28.5;
            Console.WriteLine("Area = " + length * width);
        }*/
    }
}
