﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VariableCSharp
{
    class Program12
    {
        //Để tạo ra biến lưu được các ký tự như tên, địa chỉ, bạn cần khai báo biến với kiểu dữ liệu là string
        /*static void Main(string[] args)
        {
            string name = "Codelearn";
            Console.WriteLine("Hello " + name);
        }*/
    }
}
