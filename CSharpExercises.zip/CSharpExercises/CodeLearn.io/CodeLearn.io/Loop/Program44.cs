﻿using System;

namespace Loop
{
    public class Program44
    {
        //Bạn hãy viết chương trình nhập vào từ bàn phím số nguyên a và b. Sau đó hiển thị ra màn hình tổng các số từ a tới b
        static void Main(string[] args) {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int answer = 0;
            for (int i = a; i <= b; i++) {
                // answer += i tương đương với answer = answer + i
                answer += i;
            }
            Console.WriteLine(answer);
        }
    }
}