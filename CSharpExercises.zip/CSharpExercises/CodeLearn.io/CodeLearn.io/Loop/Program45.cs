﻿using System;

namespace Loop
{
    public class Program45
    {
        //Bạn hãy viết chương trình nhập vào từ bàn phím số nguyên n và thực hiện hiển thị ra tổng các số lẻ từ 0 tới n
        static void Main(string[] args) {
            int n = int.Parse(Console.ReadLine());
            int answer = 0;
            for (int i = 0; i <= n; i++) {
                if (i % 2 != 0) {
                    answer += i;
                }
            }
            Console.WriteLine(answer);
        }
    }
}