﻿using System;

namespace Loop
{
    public class Program47
    {
        //Bạn hãy viết chương trình nhập từ bàn phím số nguyên n và hiển thị ra màn hình n! (n giai thừa)
        static void Main(string[] args) {
            int n = int.Parse(Console.ReadLine());
            int answer = 1;
            for (int i = 1; i <= n; i++) {
                // answer *= i tương đương với answer = answer * i;
                answer *= i;
            }
            Console.Write(answer);
        }
    }
}