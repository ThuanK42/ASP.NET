﻿using System;

namespace Loop
{
    public class Program43
    {
        //Bạn hãy viết chương trình nhập vào từ bàn phím số nguyên n và thực hiện hiển thị các số từ n về -n
        static void Main(string[] args) {
            int n = int.Parse(Console.ReadLine());
            for (int i = n; i >= -n; i--) {
                Console.Write(i + " ");
            }
        }
    }
}