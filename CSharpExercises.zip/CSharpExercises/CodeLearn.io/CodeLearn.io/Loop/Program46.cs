﻿using System;

namespace Loop
{
    public class Program46
    {
        //Bạn hãy viết chương trình nhập vào từ bàn phím số nguyên a và b.
        //Sau đó hiển thị ra màn hình các số chia hết cho 3 từ a tới b:
        static void Main(string[] args) {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            for (int i = a; i <= b; i++) {
                if (i % 3 == 0) {
                    Console.Write(i + " ");
                }
            }
        }
    }
}