﻿using System;

namespace Loop
{
    public class Program42
    {
        
        //Cho số nguyên a và b được nhập vào từ bàn phím,
        //bạn hãy viết chương trình hiển thị ra màn hình các số từ a tới b.
        static void Main(string[] args) {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            for (int i = a; i <= b; i++) {
                Console.Write(i + " ");
            }
        }
    }
}