﻿using System;

namespace Loop
{
    public class Program49
    {
        //Bạn hãy viết chương trình hiển thị ra màn hình các số từ 0 tới 24
        static void Main(string[] args) {
            for (int i = 0; i < 5; i++) {
                for (int j = 0; j < 5; j++) {
                    Console.Write(i * 5 + j + " ");
                }
                Console.WriteLine();
            }
        }
    }
}