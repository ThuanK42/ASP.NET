﻿using System;

namespace Loop
{
    public class Program41
    {
        static void Main(string[] args) {
            //Bạn hãy viết chương trình nhập vào từ bàn phím số nguyên n
            //và hiển thị ra các số từ 1 tới n, mỗi số cách nhau bởi 1 khoảng trắng
            int n = int.Parse(Console.ReadLine());
            for (int i = 1; i <= n; i++) {
                Console.Write(i + " ");
            }
        }
    }
}