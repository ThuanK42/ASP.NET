﻿using System;
using System.Collections.Generic;
using System.Text;

namespace First_CSharp_Program
{
    class Program5
    {
/*        static void Main(string[] args)
        {
            Console.WriteLine(37 * 56);
        }*/
    }
}
