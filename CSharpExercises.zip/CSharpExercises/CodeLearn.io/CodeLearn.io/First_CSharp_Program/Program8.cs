﻿﻿using System;
using System.Collections.Generic;
using System.Text;

namespace First_CSharp_Program
{
    class Program8
    {
        /*static void Main(string[] args)
        {
            Console.WriteLine("2468 + 1234 = " + (2468 + 1234));
            Console.WriteLine("2468 - 1234 = " + (2468 - 1234));
            Console.WriteLine("2468 * 1234 = " + (2468 * 1234));
            Console.WriteLine("2468 / 1234 = " + (2468 / 1234));
        }*/
    }
}
