﻿using System;

namespace First_CSharp_Program
{
    //Trong C# để hiển thị ra màn hình một dòng chữ nào đó bạn có thể sử dụng phương thức Console.WriteLine()
    class Program
    {
        /*static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
        */
    }
}
