﻿using System;
using System.Collections.Generic;
using System.Text;

namespace First_CSharp_Program
{
    class Program2
    {
       /* static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Codelearn.io!");
        }*/
    }
}
