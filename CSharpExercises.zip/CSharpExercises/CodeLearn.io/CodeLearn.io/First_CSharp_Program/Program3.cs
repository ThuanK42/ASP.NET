﻿using System;
using System.Collections.Generic;
using System.Text;

namespace First_CSharp_Program
{///
    class Program3
    {
        /*static void Main(string[] args)
        {
        //sử dụng ký tự \n để hiển thị thông tin trên nhiều dòng
            Console.WriteLine("Name: Codelearn\nDate of birth: 2019");
        }*/
    }
}
