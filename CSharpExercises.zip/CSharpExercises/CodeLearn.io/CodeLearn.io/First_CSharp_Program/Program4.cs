﻿using System;
using System.Collections.Generic;
using System.Text;

namespace First_CSharp_Program
{
    /*
     Ngoài việc sử dụng phương thức Console.WriteLine() để hiển thị ra màn hình thông tin dưới dạng các ký tự 
    thì bạn cũng có thể sử dụng câu lệnh này để hiển thị ra màn hình giá trị của các phép tính như phép cộng, phép trừ, phép nhân và phép chia
     */
    class Program4
    {
        /*static void Main(string[] args)
        {
            Console.WriteLine(313 + 122);
        }*/
    }
}
