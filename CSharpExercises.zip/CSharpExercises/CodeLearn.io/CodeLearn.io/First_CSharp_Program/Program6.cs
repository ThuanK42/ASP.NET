﻿using System;
using System.Collections.Generic;
using System.Text;

namespace First_CSharp_Program
{
    class Program6
    {
        /*static void Main(string[] args)
        {
            // Display Hello World on the screen
            Console.WriteLine("Hello, World!");
        }*/
    }
}
