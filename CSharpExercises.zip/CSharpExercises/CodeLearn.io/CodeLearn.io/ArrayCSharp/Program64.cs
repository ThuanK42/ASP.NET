﻿    using System;
using System.Collections.Generic;
using System.Text;

namespace ArrayCSharp
{
    class Program64
    {
        //Cho một mảng các số nguyên n phần tử arr. Bạn hãy viết chương trình hiển thị những số lớn hơn hoặc bằng 0 và nhỏ hơn hoặc bằng 10 trong mảng arr
/*        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];

            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < n; i++)
            {
                if (arr[i] >= 0 && arr[i] <= 10)
                {
                    Console.Write(arr[i] + " ");
                }
            }
        }*/
    }
}
