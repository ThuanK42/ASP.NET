﻿using System;

namespace ArrayCSharp
{
    class Program58
    {
        /*static void Main(string[] args)
        {
            // viết chương trình nhập vào từ bàn phím 10 số nguyên và hiển thị ra 10 số vừa nhập
            int[] a = new int[10];

            for (int i = 0; i < 10; i++)
            {
                a[i] = int.Parse(Console.ReadLine());
            }

            for (int i = 0; i < 10; i++)
            {
                Console.Write(a[i] + " ");
            }
        }*/
    }
}
