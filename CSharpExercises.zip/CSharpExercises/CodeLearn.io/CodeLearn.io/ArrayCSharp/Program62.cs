﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ArrayCSharp
{
    class Program62
    {
        //Cho một mảng các số nguyên n phần tử arr và số nguyên k được nhập từ bàn phím. Bạn hãy viết chương trình hiển thị ra màn hình số phần tử có giá trị bằng k trong mảng arr.
        /*static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];

            for (int i = 0; i < n; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            int k = int.Parse(Console.ReadLine());

            int count = 0;
            for (int i = 0; i < n; i++)
            {
                if (arr[i] == k)
                {
                    count++;
                }
            }
            Console.Write(count);
        }*/
    }
}
