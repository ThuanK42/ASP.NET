﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ArrayCSharp
{
    class Program60
    {
		//Cho một mảng các số nguyên n phần tử arr được nhập từ bàn phím. Bạn hãy viết chương trình hiển thị ra tổng của phần tử đầu tiên và cuối cùng trong mảng arr
/*		static void Main(string[] args)
		{
			int n = int.Parse(Console.ReadLine());
			int[] arr = new int[n];

			for (int i = 0; i < n; i++)
			{
				arr[i] = int.Parse(Console.ReadLine());
			}

			Console.Write(arr[0] + arr[n - 1]);
		}*/
	}
}
