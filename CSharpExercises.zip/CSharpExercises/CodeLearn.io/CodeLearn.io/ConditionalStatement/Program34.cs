﻿using System;

namespace ConditionalStatement
{
    public class Program34
    {
        /*Bạn hãy viết chương trình nhập vào từ bàn phím số 2 nguyên a và b. Sau đó hiển thị ra màn hình:
        Nếu a lớn hơn hoặc bằng b thì hiển thị ra:
        a is greater than or equal to b
        Ngược lại nếu a nhỏ hơn b thì hiển thị ra:
        a is smaller than b*/
        
        static void Main(string[] args) {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            if (a >= b) {
                Console.WriteLine("a is greater than or equal to b");
            } else {
                Console.WriteLine("a is smaller than b");
            }
        }
    }
}