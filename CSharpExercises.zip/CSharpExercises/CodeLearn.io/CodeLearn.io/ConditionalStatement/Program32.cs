﻿using System;

namespace ConditionalStatement
{
    public class Program32
    {
        //Bạn hãy viết chương trình nhập vào từ bàn phím số nguyên n.
        //Sau đó kiểm tra xem nếu n là số chẵn thì hiển thị ra
        static void Main(string[] args) {
            int n = int.Parse(Console.ReadLine());
            if (n % 2 == 0) {
                Console.WriteLine("n is an even number");
            } else {
                Console.WriteLine("n is an odd number");
            }
        }
    }
}