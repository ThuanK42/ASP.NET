﻿using System;

namespace ConditionalStatement
{
    public class Program40
    {
        /*Viết chương trình nhập từ bàn phím 3 số nguyên a, b, c. 
            Sau đó hãy kiểm tra xem a, b, c có tạo thành một dãy số tăng dần hoặc giảm dần hay không.
            Nếu a ≤ b và b ≤ c thì chỉ hiển thị:
        increasin
            Nếu a ≥ b và b ≥ c thì hiển thị:
        decreasing
            Ngược lại, nếu không vào 1 trong hai trường hợp trên thì hiển thị:
        neither increasing nor decreasing order*/
        
        static void Main(string[] args) {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            if (a <= b && b <= c) {
                Console.WriteLine("increasing");
            } else if (a >= b && b >= c) {
                Console.WriteLine("decreasing");
            } else {
                Console.WriteLine("neither increasing nor decreasing order");
            }
        }
    }
}