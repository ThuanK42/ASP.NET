﻿using System;

namespace ConditionalStatement
{
    public class Program33
    {
        /*Viết chương trình nhập vào từ bàn phím số nguyên n và hiển thị ra màn hình các thông tin tương ứng giống như sau:
        Nếu n là số nguyên dương thì hiển thị ra:
        n is a positive number
            Nếu n là số nguyên âm thì hiển thị ra:
        n is a negative number
            Nếu n = 0 thì hiển thị ra:
        n is equal to 0*/
        
        static void Main(string[] args) {
            int n = int.Parse(Console.ReadLine());
            if (n == 0) {
                Console.WriteLine("n is equal to 0");
            } else if (n < 0) {
                Console.WriteLine("n is a negative number");
            } else {
                Console.WriteLine("n is a positive number");
            }
        }
    }
}