﻿using System;

namespace ConditionalStatement
{
    public class Program35
    {
        /*Viết chương trình nhập vào tên của 2 người, bạn hãy kiểm tra xem tên của 2 người này có giống nhau không.
            Nếu có thì hiển thị ra:
        two people have the same name
        Ngược lại nếu tên của 2 người này không giống nhau thì hiển thị ra:
        two people don't have the same name*/
        static void Main(string[] args) {
            string name1 = Console.ReadLine();
            string name2 = Console.ReadLine();
            if(name1 == name2) {
                Console.WriteLine("two people have the same name");
            } else {
                Console.WriteLine("two people don't have the same name");
            }
        }

    }
}