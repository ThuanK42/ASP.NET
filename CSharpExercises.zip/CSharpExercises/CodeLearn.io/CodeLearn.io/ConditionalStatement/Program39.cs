﻿using System;

namespace ConditionalStatement
{
    public class Program39
    {
        /*Viết chương trình nhập từ bàn phím điểm của một học sinh. Biết điểm hợp lệ là điểm nằm trong đoạn từ 0 đến 10, 
        bạn hãy kiểm tra xem điểm vừa nhập có hợp lệ không, nếu có thì hiển thị ra màn hình:
        The score is valid
         Ngược lại nếu điểm không hợp lệ thì hiển thị:
        The score is not valid*/
        
        static void Main(string[] args) {
            int score = int.Parse(Console.ReadLine());
            if (score >= 0 && score <= 10) {
                Console.WriteLine("The score is valid");
            } else {
                Console.WriteLine("The score is not valid");
            }
        }
    }
}