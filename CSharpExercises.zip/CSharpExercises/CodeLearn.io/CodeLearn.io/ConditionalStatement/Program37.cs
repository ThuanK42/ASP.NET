﻿using System;

namespace ConditionalStatement
{
    public class Program37
    {
        // Viết chương trình nhập từ bàn phím 3 số nguyên. Sau đó hiển thị lên màn hình số lớn nhất trong 3 số này
        static void Main(string[] args) {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = int.Parse(Console.ReadLine());
            if (a >= b && a >= c) {
                Console.WriteLine(a);
            } else if (b >= c) {
                Console.WriteLine(b);
            } else {
                Console.WriteLine(c);
            }
        }
    }
}