﻿using System;

namespace ConditionalStatement
{
    public class Program38
    {
        /*Viết chương trình nhập từ bàn phím số nguyên a. Bạn hãy kiểm tra xem a có nằm trong đoạn [10, 100] không, 
        nếu có thì hiển thị ra màn hình:
        {P} is in the range [10, 100]
        Ngược lại hiển thị ra màn hình:
        {P} is not in the range [10, 100]*/
        
        static void Main(string[] args) {
            int a = int.Parse(Console.ReadLine());
            if (a >= 10 && a <= 100) {
                Console.WriteLine(a + " is in the range [10, 100]");
            } else {
                Console.WriteLine(a + " is not in the range [10, 100]");
            }
        }
    }
}