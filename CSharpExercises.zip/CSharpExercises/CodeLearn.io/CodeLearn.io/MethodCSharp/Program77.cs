﻿using System;

namespace MethodCSharp
{
    public class Program77
    {
        //Bạn hãy viết phương thức hiển thị ra màn hình những xâu có độ dài lớn hơn 3 trong mảng arr
        public static void Show(string[]arr) {
            for(int i = 0; i < arr.Length; i++) {
                if(arr[i].Length > 3) {
                    Console.Write(arr[i] + " ");
                }
            }
        }

        static void Main(string[] args) {
            int n = int.Parse(Console.ReadLine());
            string[] arr = new string[n];
            for (int i = 0; i < n; i++) {
                arr[i] = Console.ReadLine();
            }
            Show(arr);
        }
    }
}