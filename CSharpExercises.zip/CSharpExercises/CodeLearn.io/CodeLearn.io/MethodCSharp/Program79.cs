﻿using System;

namespace MethodCSharp
{
    public class Program79
    {
        //Cho hình tròn có bán kính r được nhập từ bàn phím,
        //bạn hãy viết phương thức trả về chu vi của hình tròn này biết π = 3.14
        public static double Circumference(double r) {
            return 2 * r * 3.14;
        }

        static void Main(string[] args) {
            double r = double.Parse(Console.ReadLine());
            Console.WriteLine(Circumference(r));
        }
    }
}