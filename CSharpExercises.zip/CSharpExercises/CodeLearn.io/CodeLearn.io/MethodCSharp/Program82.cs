﻿using System;

namespace MethodCSharp
{
    public class Program82
    {
        //Cho mảng các số nguyên n phần tử arr được nhập từ bàn phím.
        //Bạn hãy viết phương thức đệ quy tính tổng các phần tử của mảng
        public static int SumOfArray(int[] arr, int n) {
            if (n == 1) return arr[0];
            return arr[n - 1] + SumOfArray(arr, n - 1);
        }

        static void Main(string[] args) {
            int n = int.Parse(Console.ReadLine());
            int[] arr = new int[n];
            for (int i = 0; i < n; i++) {
                arr[i] = int.Parse(Console.ReadLine());
            }
            Console.Write(SumOfArray(arr, n));
        }
        
    }
}