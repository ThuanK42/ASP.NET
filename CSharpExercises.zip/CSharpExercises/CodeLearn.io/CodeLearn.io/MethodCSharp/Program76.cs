﻿using System;

namespace MethodCSharp
{
    public class Program76
    {

            //Bạn hãy viết phương thức hiển thị ra màn hình
            //các số chia hết cho 3 mà không chia hết cho 5 trong mảng các số nguyên arr được nhập vào từ bàn phím
            public static void Show(int[] arr) {
                for(int i = 0; i < arr.Length; i++) {
                    if(arr[i] % 3 == 0 && arr[i] % 5 != 0) {
                        Console.Write(arr[i] + " ");
                    }
                }
            }
            static void Main(string[] args) {
                int n = int.Parse(Console.ReadLine());
                int[] arr = new int[n];
                for (int i = 0; i < n; i++) {
                    arr[i] = int.Parse(Console.ReadLine());
                }
                Show(arr);
            }
        
    }
}