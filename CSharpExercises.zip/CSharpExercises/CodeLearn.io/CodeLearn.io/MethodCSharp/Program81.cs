﻿using System;

namespace MethodCSharp
{
    public class Program81
    {
        //Cho số nguyên n được nhập từ bàn phím, bạn hãy viết phương thức đệ quy trả về tổng các số lẻ từ 1 tới n
        public static int Sum(int n) {
            if (n == 1) return 1;
            if (n % 2 == 0) {
                return Sum(n - 1);
            } else {
                return n + Sum(n - 1);
            }
        }

        static void Main(string[] args) {
            int n = int.Parse(Console.ReadLine());
            Console.WriteLine(Sum(n));
        }
    }
}