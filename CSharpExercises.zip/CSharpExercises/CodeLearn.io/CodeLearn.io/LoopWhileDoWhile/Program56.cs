﻿using System;

namespace LoopWhileDoWhile
{
    public class Program56
    {
        static void Main(string[] args) {
            //hiển thị ra màn hình các số từ 1 tới 5 sử dụng vòng lặp do-while
            int i = 1;
            do {
                Console.Write(i + " ");
                i++;
            } while (i <= 5);
        }
    }
}