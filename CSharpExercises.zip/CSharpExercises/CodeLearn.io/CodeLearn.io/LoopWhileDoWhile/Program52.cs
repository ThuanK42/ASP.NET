﻿using System;

namespace LoopWhileDoWhile
{
    public class Program52
    {
        static void Main(string[] args) {
            
            //Bạn hãy viết chương trình nhập từ bàn phím hai số nguyên dương a và b.
            //Sau đó hiển thị ra màn hình kết quả của ab
            
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int answer = 1;
            for (; b > 0; b--) {
                answer *= a;
            }
            Console.Write(answer);
        }
    }
}