﻿using System;

namespace LoopWhileDoWhile
{
    public class Program50
    {
        static void Main(string[] args) {
            //Bạn hãy viết chương trình nhập vào bàn phím số nguyên n và hiển thị ra các số chẵn từ n tới 100
            int n = int.Parse(Console.ReadLine());
            for (int i = n; i <= 100; i++) {
                if (i % 2 == 0) {
                    Console.Write(i + " ");
                }
            }
        }
    }
}