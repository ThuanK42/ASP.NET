﻿using System;

namespace LoopWhileDoWhile
{
    public class Program54
    {
        //hiển thị ra các số từ 1 tới 50
        static void Main(string[] args) {
            for (int i = 1; i <= 100; i++) {
                if (i == 51) {
                    break;
                }
                Console.Write(i + " ");
            }
        }
    }
}