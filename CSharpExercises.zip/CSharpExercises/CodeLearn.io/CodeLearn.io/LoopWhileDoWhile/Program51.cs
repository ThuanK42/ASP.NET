﻿using System;

namespace LoopWhileDoWhile
{
    public class Program51
    {
        static void Main(string[] args) {
            
            //Bạn hãy viết chương trình nhập từ bàn phím số nguyên n và hiển thị ra màn hình số các ước số của n
            
            int n = int.Parse(Console.ReadLine());
            int answer = 0;
            for (int i = 1; i <= n; i++) {
                if (n % i == 0) {
                    answer++;
                }
            }
            Console.Write(answer);
        }
    }
}