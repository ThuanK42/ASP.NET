﻿using System;

namespace LoopWhileDoWhile
{
    public class Program53
    {
        static void Main(string[] args) {
            //Bạn hãy viết chương trình nhập từ bàn phím hai số nguyên a và b.
            //Sau đó hiển thị ra màn hình các số từ a tới b mà chia hết cho cả 3 và 5.
            
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            for (int i = a; i <= b; i++) {
                if (i % 3 == 0 && i % 5 == 0) {
                    Console.Write(i + " ");
                }
            }
        }
    }
}