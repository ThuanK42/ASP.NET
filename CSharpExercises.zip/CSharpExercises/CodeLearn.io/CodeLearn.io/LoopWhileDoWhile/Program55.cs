﻿using System;

namespace LoopWhileDoWhile
{
    public class Program55
    {
        static void Main(string[] args) {
            //hiển thị ra các số lẻ từ 1 tới 100
            
            for (int i = 1; i <= 100; i++) {
                if (i % 2 == 0) {
                    continue;
                }
                Console.Write(i + " ");
            }
        }
    }
}