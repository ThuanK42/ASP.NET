﻿using System;

namespace OperatorCSharp
{
    public class Program28
    {
        //Cho 2 biến kiểu số nguyên a và b được nhập từ bàn phím,
        //bạn hãy viết chương trình hoán đổi giá trị của biến a và biến b. Sau đó hiển thị ra màn hình
        
        static void Main(string[] args) {
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            int c = a;
            a = b;
            b = c;
            Console.WriteLine("after swapping, a = " + a + ", b = " + b);
        }
    }
}