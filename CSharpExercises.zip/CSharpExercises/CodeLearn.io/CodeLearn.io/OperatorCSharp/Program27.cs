﻿using System;

namespace OperatorCSharp
{
    public class Program27
    {
        //nhập vào từ bàn phím tên, tuổi của một người. Sau đó hiển thị ra màn hình
        static void Main(string[] args) {
            string name = Console.ReadLine();
            int age = int.Parse(Console.ReadLine());
            Console.WriteLine("In 15 years, age of " + name + " will be " + (age + 15));
        }
    }
}