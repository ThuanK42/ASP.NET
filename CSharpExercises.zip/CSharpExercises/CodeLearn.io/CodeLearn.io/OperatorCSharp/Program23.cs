﻿using System;

namespace OperatorCSharp
{
    public class Program23
    {
        static void Main(string[] args)
        {
            //Bạn hãy viết chương trình tạo ra 2 biến kiểu số nguyên a và b.
            //Sau đó nhập giá trị cho biến a và b từ bàn phím và hiển thị ra màn hình
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine(a + b);
        }
    }
}