﻿using System;

namespace OperatorCSharp
{
    public class Program29
    {
        static void Main(string[] args) {
            //Viết chương trình nhập vào bán kính r của một hình tròn
            //và hiển thị ra màn hình chu vi của hình tròn đó biết π = 3.14
            double r = double.Parse(Console.ReadLine());
            double pi = 3.14;
            Console.WriteLine("Circumference = " + (2 * pi * r));
        }
    }
}