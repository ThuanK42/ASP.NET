﻿using System;

namespace OperatorCSharp
{
    public class Program30
    {
        static void Main(string[] args) {
            //Bạn hãy viết chương trình nhập vào một ký tự từ bàn phím
            //và thực hiện hiển thị ký tự tiếp trong bảng bảng chữ cái của ký tự đó ra màn hình
            char c = (char)(char.Parse(Console.ReadLine()) + 1);
            Console.WriteLine(c);
        }
    }
}