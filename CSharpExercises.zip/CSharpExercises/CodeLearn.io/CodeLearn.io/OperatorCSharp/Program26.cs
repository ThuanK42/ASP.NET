﻿using System;

namespace OperatorCSharp
{
    public class Program26
    {
        static void Main(string[] args) {
            //nhập vào từ bàn phím 2 số nguyên a và b. Sau đó hiển thị ra các phép tính trên 2 số này
            
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("a + b = " + (a + b));
            Console.WriteLine("a - b = " + (a - b));
            Console.WriteLine("a * b = " + (a * b));
            Console.WriteLine("a / b = " + (a / b));
            Console.WriteLine("a % b = " + (a % b));
        }
    }
}