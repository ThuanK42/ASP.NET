﻿using System;

namespace OperatorCSharp
{
    class Program21
    {
        //Bạn hãy viết chương trình nhập vào tên của mình từ bàn phím và thực hiện hiển thị ra màn hình dòng chữ
        /*static void Main(string[] args)
        {
            string name = Console.ReadLine();
            Console.WriteLine("Hello " + name);
        }*/
    }
}
