﻿using System;

namespace OperatorCSharp
{
    public class Program22
    {
        static void Main(string[] args)
        {
            //Bạn hãy viết chương trình nhập vào tên và địa chỉ của một người sau đó hiển thị ra màn hình
            string name = Console.ReadLine();
            string address = Console.ReadLine();
            Console.WriteLine("Name: " + name);
            Console.WriteLine("Address: " + address);
        }
    }
}