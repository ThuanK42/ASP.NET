﻿using System;

namespace OperatorCSharp
{
    public class Program25
    {
        static void Main(string[] args)
        {
            //Cho 2 biến kiểu số nguyên a và b được nhập từ bàn phím, bạn hãy viết chương trình hiển thị ra màn hình
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine("a % b = " + (a - b * (a / b)));
        }
        
    }
}