﻿using System;

namespace OperatorCSharp
{
    public class Program31
    {
        static void Main(string[] args) {
            //Cho hai biến a và b kiểu số nguyên được nhập vào từ bàn phím,
            //bạn hãy viết chương trình hiển thị ra màn hình true nếu a lớn hơn b, ngược lại hiển thị ra false
            int a = int.Parse(Console.ReadLine());
            int b = int.Parse(Console.ReadLine());
            Console.WriteLine(a > b);
        }
    }
}