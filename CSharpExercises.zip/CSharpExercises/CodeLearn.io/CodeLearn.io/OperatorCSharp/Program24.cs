﻿using System;

namespace OperatorCSharp
{
    public class Program24
    {
        static void Main(string[] args)
        {
            //nhập từ bàn phím chiều dài và chiều rộng của một hình chữ nhật (chiều dài và chiều rộng
            //của hình chữ nhật này là một số nguyên) sau đó hiển thị ra màn hình
            int length = int.Parse(Console.ReadLine());
            int width = int.Parse(Console.ReadLine());
            Console.WriteLine("Area = " + length * width);
        }
    }
}