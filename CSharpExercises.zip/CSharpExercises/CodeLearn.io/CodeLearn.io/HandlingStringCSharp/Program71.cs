﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HandlingStringCSharp
{

    class Program71
    {
        /*        //Cho hai xâu ký tự s1 và s2 được nhập vào từ bàn phím, bạn hãy viết chương trình hiển thị ra vị trí đầu tiên mà s2 xuất hiện trong s1 (không phân biệt hoa thường).
                static void Main(string[] args)
                {
                    string s1 = Console.ReadLine();
                    string s2 = Console.ReadLine();
                    s1 = s1.ToLower();
                    s2 = s2.ToLower();
                    Console.WriteLine(s1.IndexOf(s2));
                }*/

        #region
        //1. Phương thức Replace:Phương thức này dùng để thay thế các chuỗi/ký tự được tìm thấy thành chuỗi/ký tự khác
        /*        static void Main(string[] args)
                {
                    Console.WriteLine("Cod3l3arn".Replace('3', 'e'));
                    Console.WriteLine("Blackcat".Replace("Black", "White"));
                }*/
        #endregion

        #region
        //2. Phương thức ToUpper/ToLower:Đây là hai phương thức dùng để chuyển các ký tự của một xâu từ in thường về in hoa và ngược lại.
        /*static void Main(string[] args)
        {
            string s = "CoDeLeArN";
            Console.WriteLine(s.ToUpper());
            Console.WriteLine(s.ToLower());
        }*/
        #endregion

        #region
        // 3. Phương thức IndexOf:Phương thức này trả về vị trí xuất hiện đầu tiên của một string trong string khác, nếu không tìm thấy thì trả về -1
        /*static void Main(string[] args)
        {
            string s = "Codelearn";
            Console.WriteLine(s.IndexOf("learn"));
            Console.WriteLine(s.IndexOf("black"));
        }*/
        #endregion

        #region
        //4. Phương thức StartsWith và EndsWith:Phương thức này dùng để kiểm tra một xâu có bắt đầu hoặc kết thúc băng một xâu khác không
        /*static void Main(string[] args)
        {
            string name = "Codelearn";
            Console.WriteLine(name.StartsWith("Code"));
            Console.WriteLine(name.StartsWith("abc"));
            Console.WriteLine(name.EndsWith("rn"));
            Console.WriteLine(name.EndsWith("z"));
        }*/

        #endregion

        #region
        //5. Phương thức Split:Phương thức này dùng để tách một xâu ra thành mảng các xâu dựa trên một ký tự cho trước
        /*static void Main(string[] args)
        {
            string s = "Welcome to Codelearn!";
            string[] words = s.Split(' ');
            for (int i = 0; i < words.Length; i++)
            {
                Console.WriteLine(words[i]);
            }
        }*/
        #endregion

        #region
        //6. Phương thức Substring:Đây là phương thức dùng để lấy ra một xâu con dựa trên chỉ số bắt đầu và chỉ số kết thúc của một xâu khác
        /*static void Main(string[] args)
        {
            string name = "Codelearn";
            Console.WriteLine(name.Substring(0, 2));
            Console.WriteLine(name.Substring(0, 4));
            Console.WriteLine(name.Substring(4));
        }*/
        #endregion





    }
}
