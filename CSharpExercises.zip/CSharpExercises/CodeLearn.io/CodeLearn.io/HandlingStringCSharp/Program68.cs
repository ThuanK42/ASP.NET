﻿using System;

namespace HandlingStringCSharp
{
    class Program68
    {
        /*static void Main(string[] args)
        {
            //Cho xâu s và số nguyên k được nhập từ bàn phím. Bạn hãy viết chương trình in ra màn hình ký tự thứ k trong xâu s.
            string s = Console.ReadLine();
            int k = int.Parse(Console.ReadLine());
            Console.WriteLine(s[k - 1]);
        }*/
    }
}
