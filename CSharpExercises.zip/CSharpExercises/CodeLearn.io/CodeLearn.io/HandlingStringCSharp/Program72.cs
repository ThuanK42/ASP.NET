﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HandlingStringCSharp
{
    class Program72
    {
        //Cho xâu s được nhập vào từ bàn phím, bạn hãy viết chương trình hiển thị ra màn hình những ký tự không phải là số trong xâu s
        /*static void Main(string[] args)
        {
            string s = Console.ReadLine();
            for (char c = '0'; c <= '9'; c++)
            {
                s = s.Replace(c + "", "");
            }
            Console.WriteLine(s);
        }*/

        
        /*static void Main(string[] args)
        {
            for (char c = '0'; c <= '9'; c++)
            {
                // in ra so cua ky tu
                Console.Write(c);
            }
            Console.WriteLine();
            for (char c = 'a'; c <= 'z'; c++)
            {
                // in ra ky tu
                Console.Write(c);
            }
        }*/
    }
}
