﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HandlingStringCSharp
{
    class Program69
    {
/*		//Cho xâu s và ký tự c được nhập từ bàn phím. Bạn hãy viết chương trình in ra số lần xuất hiện của ký tự c trong xâu s.
		static void Main(string[] args)
		{
			string s = Console.ReadLine();
			char c = char.Parse(Console.ReadLine());
			int answer = 0;
			for (int i = 0; i < s.Length; i++)
			{
				if (s[i] == c)
				{
					answer++;
				}
			}
			Console.WriteLine(answer);
		}*/
	}
}
